/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Omer
 */
public class fenetreConnexion extends JFrame {
    private JPanel container= new JPanel();
    private JTextField jtf1 = new JTextField("");
    private JTextField jtf2 = new JTextField("");
    private JComboBox combo = new JComboBox();
    private JComboBox statut = new JComboBox();
    private JLabel label3 = new JLabel("base de donnée");
    private JLabel label4 = new JLabel("Statut");
    private JLabel label1 = new JLabel("Identifiant");
    private JLabel label2 = new JLabel("Mot de passe");
    private JButton b =new JButton("Valider");
    private JFrame frame = new JFrame();
   

    
    
    
   
    
    
    public fenetreConnexion(){
     JFrame frame = new JFrame();
      this.setTitle("Connexion");
      this.setSize(800,600);
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      this.setLocationRelativeTo(null);
      container.setBackground(Color.red);
      GridBagLayout layout = new GridBagLayout();
      this.setLayout(layout);
      
      JPanel content = new JPanel();
      content.setPreferredSize(new Dimension(300,120));
      content.setBackground(Color.white);
      content.setLayout(new GridBagLayout());
      jtf1.setPreferredSize(new Dimension(100, 20));
      jtf2.setPreferredSize(new Dimension(100, 20));
      b.setPreferredSize(new Dimension(100, 20));
      
      // Action du bouton
      b.addActionListener(new ActionListener(){  
            
        public void actionPerformed(ActionEvent e){  
            // On recuperer password et identifiant
      String identifiant =jtf1.getText();
      String password=jtf2.getText();
      
      String resulatCombo = statut.getSelectedItem().toString();
      
      // Connexion
      connexion co = new connexion();
      connexionEleve co1 = new connexionEleve();
      connexionAdmin co2 = new connexionAdmin();
      
      if(resulatCombo=="Etudiant")
      {
         try{
           
           if(co1.connexionEleve(identifiant,password))
           {
               
               dispose();
               
           }
           else
           {
               JOptionPane.showMessageDialog(frame,"Erreur de Connexion");
           }
           
      }
      
      catch(Exception f){
          
      } 
      }
      
      if(resulatCombo=="Enseignant")
      {
           try{
               
           if(co.connexion(identifiant,password))
           {
              dispose(); 
           }
           else{
               JOptionPane.showMessageDialog(frame,"Erreur de Connexion");
           }
           
           
      }
      
      catch(Exception f){
          
      } 
          
      }
      if(resulatCombo=="Admin")
      {
          
           try{
               if(co2.connexionAdmin(identifiant,password))
               {
                   dispose();
               }
               else{
                   JOptionPane.showMessageDialog(frame,"Erreur de Connexion");
               }
           
      }
      
      catch(Exception f){
          
      } 
         
      }
      if(resulatCombo=="")
      {
          JOptionPane.showMessageDialog(frame,"Veuillez remplir tous les champs");;
      }
      
        
        }});
      
      GridBagConstraints gbc = new GridBagConstraints();
      combo.setPreferredSize(new Dimension(100, 17));
      combo.addItem("");
      combo.addItem("ecole");
      statut.setPreferredSize(new Dimension(100, 17));
      statut.addItem("");
      statut.addItem("Enseignant");
      statut.addItem("Etudiant");
      statut.addItem("Admin");
       gbc.gridx = 0;
       gbc.gridy = 0;
    //La taille en hauteur et en largeur
      gbc.gridheight = 1;
      gbc.gridwidth = 1;
      
      content.add(label3,gbc);
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.gridx=1;
      content.add(combo,gbc);
      //retour a la ligne
      
      gbc.gridx=0;
      gbc.gridy=2;
      gbc.gridwidth = 1;
      gbc.gridheight = 1;
      
      content.add(label4,gbc);
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.gridx=1;
      content.add(statut,gbc);
      
      
      gbc.gridx=0;
      gbc.gridy=3;
      gbc.gridwidth = 1;
      gbc.gridheight = 1;
      
      content.add(label1,gbc);
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.gridx=1;
      content.add(jtf1,gbc);
      
      gbc.gridx=0;
      gbc.gridy=4;
      gbc.gridwidth = 1;
      gbc.gridheight = 1;
      content.add(label2,gbc);
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.gridx=1;
      content.add(jtf2,gbc);
      
      gbc.gridx=0;
      gbc.gridy=5;
      content.add(b);
      
    
      
  
   
      this.setContentPane(content);
        this.setVisible(true);
      
      
}
  
    
    
    
}
