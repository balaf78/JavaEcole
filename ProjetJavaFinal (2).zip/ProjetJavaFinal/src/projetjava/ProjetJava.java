/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.SQLException;
import javax.swing.JFrame;

/**
 *
 * @author Omer
 */


public class ProjetJava extends JFrame {
    
public void fermer()
{
    dispose();

}
    /**
     * @param args the command line arguments
     */
    // Dans mon cas le nom de ma base est test et le nom de la table est java
    
    
    public static void main(String[] args) throws Exception {
        
         //fenetreConnexion fen3 = new fenetreConnexion();
         //trimestreEleve trim = new trimestreEleve("jouer");
         NewJFrame frame = new NewJFrame(); 
         frame.setVisible(true);
         
         //AccueilEtudiant fen1 = new AccueilEtudiant();
         //AccueilProf fen2 = new AccueilProf();
         
   }    

   
   
    
       
        
        
        
        }

    

    
    /*
    Autre methode:
    try
    PrepareStatement statement = this.connect.prepareStatement("INSERT INTO tab (,) VAlues(?,?)"
    );
    statement.setObject(1,obj.getM_Id() , Types.INTEGER);
    statement.setObject(2,obj.getM_Id() , Types.Varchar);
    statement.executeUpdate();
    
    
    
    
    */
    

