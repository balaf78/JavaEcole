/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Omer
 */
public class connexionAdmin {
     private String query;
    
    public boolean connexionAdmin(String identifiant, String password){
        

    try{
            
        
        ResultSet set = null;
        Connection tmp = DriverManager.getConnection("jdbc:mysql://localhost:3306/etudiant","root","");
        Statement stm = tmp.createStatement();
        query = "Select * From Admin where Identifiant='"+identifiant+"' and Password='"+password+"' ";
        
        set =stm.executeQuery(query);
        
        if(set.next())
        {
            System.out.println("Connexion réussit");
            return(true);
            
        }
        else{
            
            return(false);
        }
      
        }
        
        catch(Exception e){
        
        return(false);}
    
}
    
    
}
