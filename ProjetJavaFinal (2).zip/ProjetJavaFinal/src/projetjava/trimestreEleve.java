/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

import java.awt.BorderLayout;
import java.util.Locale;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 *
 * @author Omer
 */
public class trimestreEleve extends JFrame{
    
    private JLabel label1 = new JLabel();
    private JButton button = new JButton("Détail");
    
    public trimestreEleve(String numBulletin)
    {
        this.setTitle("Trimestre");
        this.setSize(800,600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        label1.setText(numBulletin);
        button.setSize(10,10);
        JPanel content = new JPanel();
        content.setLayout(new BorderLayout());
        content.add(label1,BorderLayout.NORTH);
        
        content.add(button,BorderLayout.SOUTH);
        
        
        
            Object [][] donnees = {
        
        {"",""}
    };
    String title[]={"Moyenne générale","Appréciation globale"};
    JTable tableau = new JTable(donnees,title);
    
    content.add(tableau,BorderLayout.CENTER);
    this.setContentPane(content);
    this.getContentPane().add(new JScrollPane(tableau));
    
    this.setVisible(true);
        
        
    }
    
            
        
    }
    
    
    
    

