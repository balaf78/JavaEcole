/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 *
 * @author Omer
 */
public class connexion {
    private String query;
    
    public boolean connexion(String identifiant, String password) throws SQLException, ClassNotFoundException
    {   
        try{
            
        
        ResultSet set = null;
        Connection tmp = DriverManager.getConnection("jdbc:mysql://localhost:3306/etudiant","root","");
        Statement stm = tmp.createStatement();
        query = "Select * From prof where Identifiant='"+identifiant+"' and Password='"+password+"' ";
        
        set =stm.executeQuery(query);
        
        if(set.next())
        {
            System.out.println("Connexion réussit");
            return(true);
            
        }
        else{
            
            return(false);
        }
      
        }
        
        catch(Exception e){
        
        return(false);}
        
            
        
    }
      
    
    
}
